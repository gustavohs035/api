import better from "better-sqlite3"

const db = better("db.sqlite")

export default db